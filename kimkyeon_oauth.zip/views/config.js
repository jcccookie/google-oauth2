export const CLIENT = {
  CLIENT_ID: "1012721389985-069bh4kmrkvn2s0hra15d621h887t63g.apps.googleusercontent.com",
  CLIENT_SECRET: "deu9lOhFbEczRjAHnJYUPBa5",
}

export const OAUTH_PROVIDER = "https://accounts.google.com/o/oauth2/v2/auth";

// export const REDIRECT_URL = "http://localhost:8080";
export const REDIRECT_URL = "https://theta-turbine-313122.wn.r.appspot.com";

export const GOOGLE_APIS = "https://www.googleapis.com/oauth2/v4/token";

export const GOOGLE_PEOPLE = "https://people.googleapis.com/v1/people/me?personFields=names";

export const generateState = length => {
  const characters ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  let result = ' ';
  const charactersLength = characters.length;

  for ( let i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }

  return result;
}

export const readCookie = cname => {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');

  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
};